import { type FormEvent, useEffect, useRef, useState } from "react";
import { Eye, EyeOff, Loader2, Lock, QrCode, RefreshCw, Smartphone, User } from "lucide-react";
import QRCode from "qrcode";
import { useSession } from "@/lib/session";
import { db } from "@/lib/store";
import { pollQrLogin, rememberQrStation, startQrLogin, loginThisDevice, linkQrDevice, probeLoginAccess, forgetThisDevice } from "@/lib/qr-auth";
import { devicePrint, readLocalDevice } from "@/lib/device-print";
import { deviceLabelFromUa } from "@/lib/device-meta";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ThemeToggle } from "@/components/theme-toggle";
import { ViewportToggle } from "@/components/viewport-toggle";
import { useViewport } from "@/lib/use-viewport";
import { cn } from "@/lib/utils";

function handsetNow() {
  if (typeof window === "undefined") return false;
  const ua = navigator.userAgent || "";
  return (
    document.documentElement.classList.contains("is-phone") ||
    window.matchMedia("(max-width: 900px)").matches ||
    /iPhone|iPod|Android.+Mobile|webOS/i.test(ua)
  );
}

function shortIp(ip: string) {
  if (ip.includes(":") && ip.length > 20) {
    const parts = ip.split(":").filter(Boolean);
    if (parts.length > 2) return `${parts[0]}:${parts[1]}:…:${parts[parts.length - 1]}`;
  }
  return ip;
}
function withTimeout<T>(work: Promise<T>, ms: number, message: string): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = window.setTimeout(() => reject(new Error(message)), ms);
    work.then(
      (value) => {
        window.clearTimeout(timer);
        resolve(value);
      },
      (err) => {
        window.clearTimeout(timer);
        reject(err instanceof Error ? err : new Error(message));
      },
    );
  });
}

export function LoginScreen({
  mediaActive = true,
  entering = false,
  leaving = false,
}: {
  mediaActive?: boolean;
  entering?: boolean;
  leaving?: boolean;
}) {
  const { signIn, signInUser } = useSession();
  const [mode, setMode] = useState<"senha" | "qr">("senha");
  const [identificador, setIdentificador] = useState("");
  const [senha, setSenha] = useState("");
  const [remember, setRemember] = useState(false);
  const [show, setShow] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [shake, setShake] = useState(0);
  const [probe, setProbe] = useState<{
    ip: string;
    os: string;
    browser: string;
    deviceKind: string;
    known: boolean;
    knownUser: string;
    knownLabel: string;
  } | null>(null);

  useEffect(() => {
    const root = document.documentElement;
    if (!root.classList.contains("dark")) root.style.colorScheme = "light";
  }, []);

  useEffect(() => {
    const savedRemember = db.loadRemember();
    if (savedRemember) {
      setIdentificador(savedRemember.identificador);
      setSenha(savedRemember.senha);
      setRemember(true);
    }
    const saved = readLocalDevice();
    let cancel = false;
    const slow = window.setTimeout(() => {
      if (cancel) return;
      void fetch("/api/ip", { credentials: "same-origin" })
        .then((r) => r.json())
        .then((info: { ip?: string; os?: string; browser?: string; deviceKind?: string }) => {
          if (cancel) return;
          setProbe((prev) => prev ?? {
            ip: info.ip || "",
            os: info.os || "",
            browser: info.browser || "",
            deviceKind: info.deviceKind || "computer",
            known: false,
            knownUser: "",
            knownLabel: "",
          });
        })
        .catch(() => {
          if (cancel) return;
          setProbe((prev) => prev ?? {
            ip: "",
            os: "",
            browser: "",
            deviceKind: "computer",
            known: false,
            knownUser: "",
            knownLabel: "",
          });
        });
    }, 2000);
    void (async () => {
      try {
        const info = await probeLoginAccess({
          data: { print: devicePrint(), deviceId: saved.deviceId, deviceSecret: saved.deviceSecret },
        });
        if (cancel) return;
        setProbe({
          ip: info.ip,
          os: info.os,
          browser: info.browser,
          deviceKind: info.deviceKind,
          known: info.known,
          knownUser: "knownUser" in info ? String(info.knownUser || "") : "",
          knownLabel: "knownLabel" in info ? String(info.knownLabel || "") : "",
        });
        if (!info.known) return;
        const res = await loginThisDevice({
          data: { deviceId: saved.deviceId, deviceSecret: saved.deviceSecret, print: devicePrint() },
        });
        if (cancel || !res.ok) return;
        try {
          localStorage.setItem("jg-device", JSON.stringify({ deviceId: res.deviceId, secret: res.secret }));
        } catch {
          /* ignore */
        }
        signInUser(res.user, res.senha, true);
      } catch {
        if (!cancel) {
          setProbe((prev) => prev ?? {
            ip: "",
            os: "",
            browser: "",
            deviceKind: "computer",
            known: false,
            knownUser: "",
            knownLabel: "",
          });
        }
      }
    })();
    return () => {
      cancel = true;
      window.clearTimeout(slow);
    };
  }, [signInUser]);

  const lock = useRef(false);

  function readField(id: string, fallback: string) {
    const el = document.getElementById(id) as HTMLInputElement | null;
    const dom = el?.value?.trim() ?? "";
    return dom || fallback.trim();
  }

  async function entrar(e?: FormEvent) {
    e?.preventDefault();
    e?.stopPropagation();
    if (lock.current) return;
    const email = readField("login-id", identificador);
    const pass = readField("login-senha", senha);
    if (email !== identificador) setIdentificador(email);
    if (pass !== senha) setSenha(pass);
    if (!email || !pass) {
      setError("Informe e-mail e senha.");
      setShake((n) => n + 1);
      return;
    }
    lock.current = true;
    setError(null);
    setSubmitting(true);
    try {
      const err = await withTimeout(
        signIn(email, pass, remember),
        12000,
        "A entrada demorou demais. Tente de novo.",
      );
      if (err) {
        setError(err);
        setShake((n) => n + 1);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível entrar. Tente de novo.");
      setShake((n) => n + 1);
    } finally {
      lock.current = false;
      setSubmitting(false);
    }
  }

  return (
    <div className={cn("login-shell", entering && "is-entering", leaving && "is-leaving")}>
      <aside className="login-panel" aria-hidden>
        <div className="login-panel-media">
          {mediaActive ? (
            <video
              className="login-video"
              src="/login-video.mp4?v=17"
              poster="/login-poster.jpg?v=17"
              autoPlay
              muted
              loop
              playsInline
              preload="metadata"
            />
          ) : (
            <img src="/login-poster.jpg?v=17" alt="" className="login-video" />
          )}
        </div>
      </aside>

      <main className="login-form-wrap">
        <div className="login-neo w-full">
          <div className="login-tools">
            <ViewportToggle compact />
            <ThemeToggle />
          </div>
          <img src="/logo.png" alt="JG Garcia" className="login-logo" />
          <div>
            <h2 className="text-2xl font-semibold tracking-tight">Entrar</h2>
            <p className="mt-1 text-sm text-muted-foreground">Acesso da equipe JG Garcia.</p>
            {probe ? (
              <p id="login-device-line" className="login-device-line">
                {probe.deviceKind === "phone" ? "Celular" : probe.deviceKind === "tablet" ? "Tablet" : "Computador"}
                {" · "}
                {probe.known && probe.knownUser ? `reconhecido como ${probe.knownUser}` : "ainda não reconhecido"}
                {probe.ip && probe.ip !== "desconhecido" ? ` · IP ${shortIp(probe.ip)}` : ""}
              </p>
            ) : (
              <p id="login-device-line" className="login-device-line">Lendo o IP deste aparelho…</p>
            )}
          </div>

          <div className={cn("login-mode-tabs", mode === "qr" && "is-qr")}>
            <span className="login-mode-pill" aria-hidden />
            <button
              type="button"
              className={cn(mode !== "qr" && "is-on")}
              onPointerUp={() => setMode("senha")}
              onClick={() => setMode("senha")}
            >
              Senha
            </button>
            <button
              type="button"
              className={cn(mode === "qr" && "is-on")}
              onPointerUp={() => setMode("qr")}
              onClick={() => setMode("qr")}
            >
              <span className="login-qr-desktop">QR Code</span>
              <span className="login-qr-phone">Dispositivo</span>
            </button>
          </div>

          <div className="login-mode-stage">
            {mode === "senha" ? (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  void entrar();
                }}
                className={cn("login-auth-form", shake ? "form-shake" : "")}
                autoComplete="on"
              >
                <div id="login-alert" role="alert" hidden={error ? undefined : true} className="rounded-lg border border-destructive/25 bg-destructive/8 px-3 py-2.5 text-sm text-destructive">
                  {error || ""}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="login-id">E-mail</Label>
                  <div className="login-field">
                    <User className="login-field-icon" />
                    <Input
                      id="login-id"
                      value={identificador}
                      onChange={(e) => setIdentificador(e.target.value)}
                      onInput={(e) => setIdentificador((e.target as HTMLInputElement).value)}
                      className="pl-10"
                      autoComplete="username"
                      placeholder="e-mail da equipe"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="login-senha">Senha</Label>
                  <div className="login-field">
                    <Lock className="login-field-icon" />
                    <Input
                      id="login-senha"
                      type={show ? "text" : "password"}
                      value={senha}
                      onChange={(e) => setSenha(e.target.value)}
                      onInput={(e) => setSenha((e.target as HTMLInputElement).value)}
                      className="pl-10 pr-11"
                      autoComplete="current-password"
                      placeholder="senha"
                    />
                    <button
                      type="button"
                      className="login-eye"
                      onClick={() => setShow((v) => !v)}
                      aria-label={show ? "Ocultar senha" : "Mostrar senha"}
                    >
                      {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <label className="login-remember">
                  <input
                    type="checkbox"
                    checked={remember}
                    onChange={(e) => setRemember(e.target.checked)}
                    className="h-4 w-4 shrink-0 accent-primary"
                  />
                  <span className="login-remember-text">Lembrar senha neste aparelho</span>
                </label>

                <Button
                  type="button"
                  className="login-submit h-11 w-full"
                  disabled={submitting}
                  onClick={() => void entrar()}
                >
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                  {submitting ? "Entrando" : "Entrar"}
                </Button>
              </form>
            ) : (
              <QrLoginPanel remember={remember} active={mode === "qr"} probe={probe} />
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

function QrLoginPanel({
  remember,
  active,
  probe,
}: {
  remember: boolean;
  active: boolean;
  probe: { known: boolean; knownUser: string; knownLabel: string; ip: string; os: string; browser: string } | null;
}) {
  const { signInUser } = useSession();
  const phone = useViewport() === "phone" || handsetNow();
  const [img, setImg] = useState<string | null>(null);
  const [left, setLeft] = useState(300);
  const [status, setStatus] = useState("Aguardando a leitura do QR…");
  const [err, setErr] = useState<string | null>(null);
  const [busyStation, setBusyStation] = useState(false);
  const [firstAccess, setFirstAccess] = useState(false);
  const [identificador, setIdentificador] = useState("");
  const [senha, setSenha] = useState("");
  const [show, setShow] = useState(false);
  const ticket = useRef<{ id: string; secret: string; expiresAt: number } | null>(null);
  const misses = useRef(0);

  function saveLocalDevice(deviceId: string, secret: string) {
    try {
      localStorage.setItem("jg-device", JSON.stringify({ deviceId, secret }));
      sessionStorage.setItem("jg-device", JSON.stringify({ deviceId, secret }));
    } catch {
      /* ignore */
    }
  }

  function forgetLocalDevice() {
    try {
      localStorage.removeItem("jg-device");
      sessionStorage.removeItem("jg-device");
    } catch {
      /* ignore */
    }
    void forgetThisDevice({ data: {} }).catch(() => undefined);
  }

  async function persistStation(userId: string) {
    try {
      const st = await rememberQrStation({ data: { userId } });
      if (st.ok) localStorage.setItem("jg-station", JSON.stringify({ id: st.id, secret: st.secret }));
    } catch {
      /* ignore */
    }
  }

  function deviceLabel() {
    return deviceLabelFromUa(navigator.userAgent);
  }

  async function enterThisPhone() {
    setBusyStation(true);
    setErr(null);
    try {
      const saved = readLocalDevice();
      const res = await withTimeout(
        loginThisDevice({
          data: { ...saved, print: devicePrint() },
        }),
        10000,
        "Não deu para reconhecer este celular agora.",
      );
      if (!res.ok) {
        setErr(res.error || "Este celular ainda não está reconhecido. Use a aba Senha, com e-mail e senha. Não precisa de computador.");
        setFirstAccess(true);
        return;
      }
      saveLocalDevice(res.deviceId, res.secret);
      void persistStation(res.user.id);
      db.recordAccess({
        usuario_id: res.user.id,
        acao: "login",
        resumo: `${res.user.nome} — Login realizado — ${probe?.browser || "Navegador"} / ${probe?.os || ""} — IP ${res.ip || "—"}`,
        detalhe: deviceLabel(),
      });
      signInUser(res.user, res.senha, remember);
    } catch (err) {
      setErr(err instanceof Error ? err.message : "Não deu para reconhecer este celular. Entre pela aba Senha.");
      setFirstAccess(true);
    } finally {
      setBusyStation(false);
    }
  }

  async function concluirPrimeiroAcesso(e?: { preventDefault(): void }) {
    e?.preventDefault();
    if (!identificador.trim() || !senha) {
      setErr("Informe o e-mail e a senha cadastrados pelo administrador.");
      return;
    }
    setBusyStation(true);
    setErr(null);
    try {
      const linked = await linkQrDevice({
        data: { identificador: identificador.trim(), senha, label: deviceLabel(), print: devicePrint() },
      });
      if (!linked.ok) {
        setErr(linked.error);
        return;
      }
      if (linked.deviceId && linked.secret) saveLocalDevice(linked.deviceId, linked.secret);
      void persistStation(linked.user.id);
      db.recordAccess({
        usuario_id: linked.user.id,
        acao: "reconheceu",
        resumo: `${linked.user.nome} — Novo dispositivo reconhecido — ${probe?.os || ""} / ${probe?.browser || ""}`,
        detalhe: linked.ip ? `IP ${linked.ip} · ${deviceLabel()}` : deviceLabel(),
      });
      signInUser(linked.user, senha, remember);
    } catch {
      setErr("Não foi possível concluir o primeiro acesso.");
    } finally {
      setBusyStation(false);
    }
  }

  async function issue() {
    try {
      setErr(null);
      const t = await startQrLogin({ data: {} });
      ticket.current = { id: t.id, secret: t.secret, expiresAt: t.expiresAt };
      const href = `${window.location.origin}/qr-acesso?t=${t.id}.${t.secret}`;
      setLeft(Math.max(1, Math.round((t.expiresAt - Date.now()) / 1000)));
      setStatus("Aponte a câmera do celular. A leitura libera este computador.");
      misses.current = 0;
      setImg(await QRCode.toDataURL(href, { width: 240, margin: 1, color: { dark: "#0c241b", light: "#fcfcfc" } }));
    } catch {
      setErr("Não foi possível gerar o QR. Toque em Novo QR para tentar de novo.");
      setImg(null);
    }
  }

  useEffect(() => {
    if (phone || !active) return;
    void issue();
    const timer = window.setInterval(() => {
      const cur = ticket.current;
      if (!cur) return;
      const s = Math.round((cur.expiresAt - Date.now()) / 1000);
      if (s <= 0) {
        void issue();
        return;
      }
      setLeft(s);
    }, 1000);
    const poll = window.setInterval(async () => {
      const cur = ticket.current;
      if (!cur) return;
      try {
        const res = await pollQrLogin({ data: { id: cur.id, secret: cur.secret } });
        if (res.status === "approved") {
          setStatus("QR lido. Entrando…");
          void persistStation(res.user.id);
          signInUser(res.user, res.senha, remember);
          return;
        }
        if (res.status === "expired") {
          void issue();
          return;
        }
        if (res.status === "missing") {
          misses.current += 1;
          if (misses.current >= 4) void issue();
        } else {
          misses.current = 0;
        }
      } catch {
        /* next poll */
      }
    }, 900);
    return () => {
      window.clearInterval(timer);
      window.clearInterval(poll);
    };
  }, [phone, remember, signInUser, active]);

  const mm = String(Math.floor(left / 60)).padStart(2, "0");
  const ss = String(left % 60).padStart(2, "0");

  if (phone) {
    if (firstAccess) {
      return (
        <form onSubmit={concluirPrimeiroAcesso} className="space-y-4">
          {err ? (
            <div role="alert" className="rounded-lg border border-destructive/25 bg-destructive/8 px-3 py-2.5 text-sm text-destructive">
              {err}
            </div>
          ) : null}
          <div>
            <h3 className="text-base font-semibold">Primeiro acesso</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Este navegador ainda não tem um token de acesso. Entre com o e-mail e a senha. O IP deste telefone é lido na hora e, se o aparelho já foi vinculado, a próxima entrada é automática.
            </p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="dev-email">E-mail</Label>
            <div className="relative">
              <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="dev-email"
                value={identificador}
                onChange={(e) => setIdentificador(e.target.value)}
                className="pl-10"
                autoComplete="username"
                autoCapitalize="none"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="dev-senha">Senha</Label>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="dev-senha"
                type={show ? "text" : "password"}
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                className="pl-10 pr-11"
                autoComplete="current-password"
              />
              <button
                type="button"
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-2 text-muted-foreground"
                onClick={() => setShow((v) => !v)}
                aria-label={show ? "Ocultar senha" : "Mostrar senha"}
              >
                {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>
          <Button type="button" className="h-11 w-full active:scale-100" disabled={busyStation} onClick={(e) => void concluirPrimeiroAcesso(e)}>
            {busyStation ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            {busyStation ? "Salvando" : "Concluir primeiro acesso"}
          </Button>
        </form>
      );
    }

    return (
      <div className="space-y-4">
        {err ? (
          <div role="alert" className="rounded-lg border border-destructive/25 bg-destructive/8 px-3 py-2.5 text-sm text-destructive">
            {err}
          </div>
        ) : null}
        <p className="text-sm text-muted-foreground">
          {probe?.known && probe.knownUser
            ? `Este telefone já foi reconhecido como ${probe.knownUser}${probe.knownLabel ? ` (${probe.knownLabel})` : ""}. O IP foi lido ao abrir a página.`
            : "O IP deste telefone é lido ao abrir. Se o aparelho já foi vinculado, a entrada é automática. Se não, use e-mail e senha — não precisa de computador."}
        </p>
        <Button type="button" className="h-11 w-full active:scale-100" onClick={() => void enterThisPhone()} disabled={busyStation}>
          {busyStation ? <Loader2 className="h-4 w-4 animate-spin" /> : <Smartphone className="h-4 w-4" />}
          {busyStation
            ? "Reconhecendo"
            : probe?.known && probe.knownUser
              ? `Entrar como ${probe.knownUser}`
              : "Reconhecer este dispositivo"}
        </Button>
        {probe?.known && probe.knownUser ? (
          <button
            type="button"
            className="w-full text-center text-xs text-muted-foreground underline-offset-2 hover:underline"
            onClick={() => {
              forgetLocalDevice();
              setFirstAccess(true);
              setErr(null);
            }}
          >
            Não sou {probe.knownUser.split(" ")[0]} — entrar com outra conta
          </button>
        ) : null}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {err ? (
        <div role="alert" className="rounded-lg border border-destructive/25 bg-destructive/8 px-3 py-2.5 text-sm text-destructive">
          {err}
        </div>
      ) : null}
      <div className="flex flex-col items-center rounded-2xl border border-border bg-card p-4">
        {img ? <img src={img} alt="QR Code para entrar" className="h-52 w-52 rounded-lg" /> : <Loader2 className="h-8 w-8 animate-spin text-primary" />}
        <p className="mt-3 flex items-center gap-1.5 text-sm text-muted-foreground">
          <QrCode className="h-4 w-4" /> {status}
        </p>
        <p className="mt-1 tabular text-xs text-muted-foreground">Expira em {mm}:{ss}</p>
      </div>
      <Button type="button" variant="outline" className="w-full" onClick={() => void issue()}>
        <RefreshCw /> Novo QR
      </Button>
      <p className="text-xs leading-relaxed text-muted-foreground">
        O celular que ler este QR entra com a conta daquele telefone e libera este computador.
      </p>
    </div>
  );
}