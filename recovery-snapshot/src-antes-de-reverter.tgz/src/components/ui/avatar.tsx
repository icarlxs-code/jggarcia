import * as React from "react";
import { cn } from "@/lib/utils";

function Avatar({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("relative flex h-9 w-9 shrink-0 overflow-hidden rounded-full", className)} {...props} />;
}

function AvatarFallback({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("flex h-full w-full items-center justify-center bg-primary text-xs font-bold text-primary-foreground", className)}
      {...props}
    />
  );
}

export { Avatar, AvatarFallback };
