import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Download, FileText, Printer, Search, X } from "lucide-react";
import { formatDateBR, formatNumber, formatTime, completeTime, isValidTime, todayISO } from "@/lib/format";
import { pavTitle } from "@/lib/catalog";
import {
  agruparMercadoria,
  agruparPavilhao,
  filtrarSaidas,
  linhaDeSaida,
  mercadoriaCombina,
  pesquisaRapida,
  resumoFamilia,
  totais,
  type FiltroSaidas,
  type SaidaLinha,
} from "@/lib/saidas-consulta";
import { exportarExcelSaidas, exportarPdfSaidas } from "@/lib/saidas-export";
import { useDb } from "@/lib/use-db";
import { db, getDbGen } from "@/lib/store";
import { notify } from "@/lib/notify";
import type { Destino, Mercadoria, Pavilhao, Saida, Usuario } from "@/lib/types";
import { cn, fold } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ProductIcon } from "@/components/inventory/product-icon";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { TimeField } from "@/components/ui/time-field";

const vazio = (): FiltroSaidas => ({
  de: todayISO(),
  ate: todayISO(),
  pav: "",
  mercadoriaId: "",
  mercadoria: "",
  destino: "",
  cliente: "",
  usuario: "",
});

function rotuloMercadoria(m: { codigo: string; nome: string }) {
  return `${m.codigo} — ${m.nome}`;
}

function num(n: number | null) {
  return n == null ? "—" : formatNumber(n);
}

function formula(g: { pallets: number | null; porPallet: number | null; total: number; unidade: string }) {
  if (g.pallets != null && g.porPallet != null) {
    return `${formatNumber(g.pallets)} × ${formatNumber(g.porPallet)} = ${formatNumber(g.total)} ${g.unidade}`;
  }
  return `${formatNumber(g.total)} ${g.unidade}`;
}

export function SaidasPainel({
  saidas,
  pavilhoes,
  destinos,
  usuarios,
  onOpen,
  onEdit,
  onDelete,
}: {
  saidas: Saida[];
  pavilhoes: Pavilhao[];
  destinos: Destino[];
  usuarios: Usuario[];
  onOpen: (s: Saida) => void;
  onEdit: (s: Saida) => void;
  onDelete: (s: Saida) => void;
}) {
  const [draft, setDraft] = useState<FiltroSaidas>(vazio);
  const [filtro, setFiltro] = useState<FiltroSaidas>(vazio);
  const [q, setQ] = useState("");
  const [grupo, setGrupo] = useState<"lista" | "mercadoria" | "pavilhao">("lista");
  const [detalhe, setDetalhe] = useState<{ titulo: string; linhas: SaidaLinha[] } | null>(null);
  const [chegada, setChegada] = useState<Saida | null>(null);
  const [horaChegada, setHoraChegada] = useState("");

  const live = useDb();
  const gen = getDbGen();
  const catalogo = useMemo(
    () => live.listMercadorias().slice().sort((a, b) => a.nome.localeCompare(b.nome, "pt-BR") || a.codigo.localeCompare(b.codigo)),
    [live, gen],
  );
  const porId = useMemo(() => new Map(catalogo.map((m) => [m.id, m])), [catalogo]);
  const linhas = useMemo(() => saidas.map((s) => linhaDeSaida(s, pavilhoes, destinos, usuarios)), [saidas, pavilhoes, destinos, usuarios]);
  const visiveis = useMemo(() => pesquisaRapida(filtrarSaidas(linhas, filtro), q), [linhas, filtro, q]);
  const soma = totais(visiveis);
  const porMercadoria = useMemo(() => agruparMercadoria(visiveis), [visiveis]);
  const porPavilhao = useMemo(() => agruparPavilhao(visiveis), [visiveis]);
  const familia = resumoFamilia(visiveis, q.trim());
  const pavNome = pavilhoes.find((p) => p.id === filtro.pav)?.nome ? pavTitle(pavilhoes.find((p) => p.id === filtro.pav)!) : filtro.pav ? filtro.pav : "Todos";
  const mercLabel = filtro.mercadoria.trim() || q.trim() || "Todas";

  function set<K extends keyof FiltroSaidas>(key: K, value: FiltroSaidas[K]) {
    setDraft((f) => ({ ...f, [key]: value }));
  }

  function limpar() {
    const next = { ...vazio(), de: "", ate: "" };
    setDraft(next);
    setFiltro(next);
    setQ("");
    setGrupo("lista");
  }

  function meta() {
    return {
      filtro,
      pavilhao: filtro.pav ? pavNome : "Todos",
      mercadoria: filtro.mercadoria.trim(),
      busca: q.trim(),
    };
  }

  function abrirGrupo(titulo: string, rows: SaidaLinha[]) {
    setDetalhe({ titulo, linhas: rows });
  }

  function abrirChegada(s: Saida) {
    setChegada(s);
    setHoraChegada((s.hora_chegada || "").slice(0, 5));
  }

  function salvarChegada() {
    if (!chegada) return;
    const hc = completeTime(horaChegada);
    if (!isValidTime(hc)) {
      notify.error("Informe o horário de chegada no formato HH:MM, tipo 14:45.");
      return;
    }
    try {
      db.markChegada(chegada.id, hc);
      notify.success("Horário de chegada registrado. O restante do lançamento não mudou.");
      setChegada(null);
    } catch (err) {
      notify.error(err instanceof Error ? err.message : "Não foi possível registrar a chegada.");
    }
  }

  return (
    <div className="space-y-3">
      <section className="relative z-20 rounded-2xl border border-border bg-card p-3 shadow-card sm:p-4">
        <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-12">
          <Campo label="Data inicial" className="xl:col-span-3">
            <Input type="date" value={draft.de} onChange={(e) => set("de", e.target.value)} />
          </Campo>
          <Campo label="Data final" className="xl:col-span-3">
            <Input type="date" value={draft.ate} onChange={(e) => set("ate", e.target.value)} />
          </Campo>
          <Campo label="Pavilhão / galpão de origem" className="xl:col-span-3">
            <Select value={draft.pav || "todos"} onValueChange={(v) => set("pav", v === "todos" ? "" : v)}>
              <SelectTrigger>
                <SelectValue placeholder="Todos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                {pavilhoes
                  .filter((p) => p.ativo !== false && !p.deleted_at)
                  .map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {pavTitle(p)}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </Campo>
          <Campo label="Mercadoria / produto" className="xl:col-span-3">
            <MercadoriaFiltro
              items={catalogo}
              valueId={draft.mercadoriaId}
              onChange={(id, label) => setDraft((f) => ({ ...f, mercadoriaId: id, mercadoria: label }))}
            />
          </Campo>
          <Campo label="Destino" className="xl:col-span-4">
            <Select value={draft.destino || "todos"} onValueChange={(v) => set("destino", v === "todos" ? "" : v)}>
              <SelectTrigger>
                <SelectValue placeholder="Todos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                {destinos.map((d) => (
                  <SelectItem key={d.id} value={d.id}>
                    {d.nome}
                  </SelectItem>
                ))}
                {pavilhoes
                  .filter((p) => p.ativo !== false && !p.deleted_at)
                  .map((p) => (
                    <SelectItem key={`d-${p.id}`} value={p.id}>
                      {pavTitle(p)}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </Campo>
          <Campo label="Cliente" className="xl:col-span-4">
            <Input value={draft.cliente} onChange={(e) => set("cliente", e.target.value)} placeholder="Nome do cliente" list="saidas-clientes" />
          </Campo>
          <Campo label="Usuário responsável" className="sm:col-span-2 xl:col-span-4">
            <Select value={draft.usuario || "todos"} onValueChange={(v) => set("usuario", v === "todos" ? "" : v)}>
              <SelectTrigger>
                <SelectValue placeholder="Todos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                {usuarios.map((u) => (
                  <SelectItem key={u.id} value={u.id}>
                    {u.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Campo>
        </div>
        <datalist id="saidas-clientes">
          {[...new Set(linhas.map((r) => r.cliente).filter(Boolean))].map((n) => (
            <option key={n} value={n} />
          ))}
        </datalist>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button type="button" onClick={() => setFiltro(draft)}>
            Filtrar
          </Button>
          <Button type="button" variant="outline" onClick={limpar}>
            <X /> Limpar filtros
          </Button>
        </div>
      </section>

      <div className="grid grid-cols-2 gap-2 lg:grid-cols-5">
        <CardKpi label="Total de saídas" value={formatNumber(soma.saidas)} />
        <CardKpi label="Total de pallets" value={num(soma.pallets)} hint={soma.pallets == null ? "Só soma quando o lançamento tem pallet" : undefined} />
        <CardKpi label="Volumes / caixas" value={`${formatNumber(soma.volumes)} ${soma.unidade}`} />
        <CardKpi label="Pavilhão" value={pavNome} />
        <CardKpi label="Mercadoria" value={mercLabel} />
      </div>

      {familia ? (
        <section className="rounded-2xl border border-border bg-card p-3 shadow-card sm:p-4">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Total geral de {familia.nome}</p>
          <ul className="mt-2 grid gap-1.5 sm:grid-cols-2 lg:grid-cols-3">
            {familia.variedades.map((v) => (
              <li key={v.nome}>
                <button
                  type="button"
                  className="flex w-full items-center justify-between rounded-xl border border-border px-3 py-2 text-left text-sm hover:bg-muted"
                  onClick={() =>
                    abrirGrupo(
                      `${familia.nome} ${v.nome}`.trim(),
                      visiveis.filter((r) => r.familia === familia.nome && (r.variedade || r.mercadoria) === v.nome),
                    )
                  }
                >
                  <span>{v.nome}</span>
                  <span className="font-semibold tabular-nums">
                    {formatNumber(v.total)} {v.unidade}
                  </span>
                </button>
              </li>
            ))}
          </ul>
          <p className="mt-2 text-sm font-semibold">
            Total de {familia.nome}: {formatNumber(familia.total)} {familia.unidade}
          </p>
        </section>
      ) : null}

      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-[12rem] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input className="pl-9" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Pesquisar mercadoria" />
        </div>
        <div className="flex flex-wrap gap-1">
          {(
            [
              ["lista", "Lista"],
              ["mercadoria", "Agrupar por mercadoria"],
              ["pavilhao", "Agrupar por pavilhão"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setGrupo(id)}
              className={cn(
                "rounded-full border px-3 py-1.5 text-xs",
                grupo === id ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card hover:bg-muted",
              )}
            >
              {label}
            </button>
          ))}
        </div>
        <Button type="button" variant="outline" size="sm" onClick={() => exportarPdfSaidas(visiveis, meta())}>
          <FileText /> PDF
        </Button>
        <Button type="button" variant="outline" size="sm" onClick={() => exportarExcelSaidas(visiveis, meta())}>
          <Download /> Excel
        </Button>
        <Button type="button" variant="outline" size="sm" onClick={() => exportarPdfSaidas(visiveis, meta())}>
          <Printer /> Imprimir
        </Button>
      </div>

      {visiveis.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground">Nenhuma saída neste filtro.</p>
      ) : grupo === "mercadoria" ? (
        <ul className="grid gap-2 sm:grid-cols-2">
          {porMercadoria.map((g) => (
            <li key={g.key}>
              <button type="button" className="w-full rounded-2xl border border-border bg-card p-3 text-left shadow-card hover:bg-muted/40" onClick={() => abrirGrupo(g.nome, g.linhas)}>
                <span className="flex items-center gap-2">
                  <ProductIcon nome={g.nome} codigo={g.linhas[0]?.codigo} foto={porId.get(g.key)?.foto || porId.get(g.key)?.foto_original} size="sm" />
                  <span className="min-w-0">
                    <p className="truncate font-medium">{g.nome}</p>
                    <p className="mt-1 text-sm text-muted-foreground">{formula(g)}</p>
                  </span>
                </span>
                <p className="text-xs text-muted-foreground">
                  {g.linhas.length} saída(s)
                  {g.pallets != null ? ` · ${formatNumber(g.pallets)} pallets` : ""}
                </p>
              </button>
            </li>
          ))}
        </ul>
      ) : grupo === "pavilhao" ? (
        <div className="space-y-3">
          {porPavilhao.map((p) => (
            <section key={p.key} className="rounded-2xl border border-border bg-card p-3 shadow-card">
              <div className="flex items-baseline justify-between gap-2">
                <h3 className="font-semibold">{p.nome}</h3>
                <p className="text-sm font-semibold tabular-nums">
                  Total: {formatNumber(p.total)} {p.unidade}
                </p>
              </div>
              <ul className="mt-2 divide-y divide-border">
                {p.produtos.map((g) => (
                  <li key={g.key}>
                    <button type="button" className="flex w-full items-center justify-between gap-3 py-2 text-left text-sm hover:bg-muted/50" onClick={() => abrirGrupo(`${g.nome} · ${p.nome}`, g.linhas)}>
                      <span className="flex min-w-0 items-center gap-2">
                        <ProductIcon nome={g.nome} codigo={g.linhas[0]?.codigo} foto={porId.get(g.key)?.foto || porId.get(g.key)?.foto_original} size="xs" />
                        <span className="truncate">{g.nome}</span>
                      </span>
                      <span className="shrink-0 tabular-nums">
                        {formatNumber(g.total)} {g.unidade}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      ) : (
        <>
          <ul className="space-y-2 sm:hidden">
            {visiveis.map((r) => (
              <li key={r.id}>
                <article
                  data-ctx="saida"
                  data-id={r.id}
                  data-produto={r.mercadoriaId}
                  data-nome={r.mercadoria}
                  data-codigo={r.codigo}
                  className="rounded-2xl border border-border bg-card p-3 shadow-card"
                >
                  <button type="button" className="flex w-full items-start gap-2 text-left" onClick={() => onOpen(r.raw)}>
                    <ProductIcon nome={r.mercadoria} codigo={r.codigo} foto={porId.get(r.mercadoriaId)?.foto || porId.get(r.mercadoriaId)?.foto_original} size="xs" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold">{r.mercadoria}</span>
                      <span className="block truncate text-xs text-muted-foreground">{r.variedade || "Sem variedade"}</span>
                    </span>
                    <span className="shrink-0 text-right text-sm font-semibold tabular-nums">
                      {formatNumber(r.total)} {r.unidade}
                    </span>
                  </button>
                  <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1.5 text-xs">
                    <Info label="Data" value={formatDateBR(r.data)} />
                    <Info label="Origem" value={r.pavilhao} />
                    <Info label="Horário de saída" value={formatTime(r.raw.hora_saida)} />
                    <div>
                      <dt className="text-[10px] uppercase tracking-wide text-muted-foreground">Horário de chegada</dt>
                      <dd className="mt-0.5">
                        <ChegadaBtn s={r.raw} onChegada={abrirChegada} />
                      </dd>
                    </div>
                    <Info label="Destino" value={r.destino} />
                    <Info label="Cliente" value={r.cliente || "—"} />
                    <Info label="Usuário" value={r.usuario || "—"} />
                  </dl>
                  <div className="mt-2 flex justify-end gap-2 border-t border-border pt-2">
                    <button type="button" className="px-1 text-xs text-muted-foreground hover:text-foreground" onClick={() => onEdit(r.raw)}>
                      Editar
                    </button>
                    <button type="button" className="px-1 text-xs text-destructive" onClick={() => onDelete(r.raw)}>
                      Excluir
                    </button>
                  </div>
                </article>
              </li>
            ))}
          </ul>
          <div className="hidden overflow-x-auto rounded-2xl border border-border bg-card shadow-card sm:block">
            <table className="w-full min-w-[980px] text-sm">
              <thead>
                <tr className="border-b border-border text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                  <th className="w-[1%] whitespace-nowrap px-3 py-2 font-medium">Data</th>
                  <th className="px-3 py-2 font-medium">Origem</th>
                  <th className="px-3 py-2 font-medium">Mercadoria</th>
                  <th className="px-3 py-2 font-medium">Variedade</th>
                  <th className="w-[1%] whitespace-nowrap px-3 py-2 font-medium">Horário de saída</th>
                  <th className="w-[1%] whitespace-nowrap px-3 py-2 font-medium">Horário de chegada</th>
                  <th className="w-[1%] whitespace-nowrap px-3 py-2 text-right font-medium">Total</th>
                  <th className="px-3 py-2 font-medium">Destino</th>
                  <th className="px-3 py-2 font-medium">Cliente</th>
                  <th className="px-3 py-2 font-medium">Usuário</th>
                  <th className="px-3 py-2" />
                </tr>
              </thead>
              <tbody>
                {visiveis.map((r) => (
                  <tr
                    key={r.id}
                    data-ctx="saida"
                    data-id={r.id}
                    data-produto={r.mercadoriaId}
                    data-nome={r.mercadoria}
                    data-codigo={r.codigo}
                    className="cursor-pointer border-b border-border last:border-0 hover:bg-muted/40"
                    onClick={() => onOpen(r.raw)}
                  >
                    <td className="whitespace-nowrap px-3 py-2">{formatDateBR(r.data)}</td>
                    <td className="px-3 py-2">{r.pavilhao}</td>
                    <td className="px-3 py-2">
                      <span className="flex items-center gap-2">
                        <ProductIcon nome={r.mercadoria} codigo={r.codigo} foto={porId.get(r.mercadoriaId)?.foto || porId.get(r.mercadoriaId)?.foto_original} size="xs" />
                        <span className="font-medium">{r.mercadoria}</span>
                      </span>
                    </td>
                    <td className="px-3 py-2">{r.variedade || "—"}</td>
                    <td className="whitespace-nowrap px-3 py-2 tabular-nums">{formatTime(r.raw.hora_saida)}</td>
                    <td className="whitespace-nowrap px-3 py-2">
                      <ChegadaBtn s={r.raw} onChegada={abrirChegada} />
                    </td>
                    <td className="whitespace-nowrap px-3 py-2 text-right font-semibold tabular-nums">
                      {formatNumber(r.total)} {r.unidade}
                    </td>
                    <td className="px-3 py-2">{r.destino}</td>
                    <td className="px-3 py-2">{r.cliente || "—"}</td>
                    <td className="px-3 py-2">{r.usuario || "—"}</td>
                    <td className="px-2 py-2 text-right" onClick={(e) => e.stopPropagation()}>
                      <button type="button" className="px-1 text-xs text-muted-foreground hover:text-foreground" onClick={() => onEdit(r.raw)}>
                        Editar
                      </button>
                      <button type="button" className="px-1 text-xs text-destructive" onClick={() => onDelete(r.raw)}>
                        Excluir
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      <Dialog open={!!chegada} onOpenChange={(o) => !o && setChegada(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Horário de chegada</DialogTitle>
          </DialogHeader>
          {chegada ? (
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">
                {chegada.mercadoria?.nome || "Mercadoria"} · {formatDateBR(chegada.data)}. Só este horário é gravado. Quantidade, origem e destino ficam como estão.
              </p>
              <TimeField id="saida-hora-chegada" value={horaChegada} onChange={setHoraChegada} aria-label="Horário de chegada" />
              <p className="text-xs text-muted-foreground">Formato HH:MM. Exemplo: 14:45. Digite 1445 que vira 14:45.</p>
            </div>
          ) : null}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setChegada(null)}>
              Cancelar
            </Button>
            <Button type="button" onClick={salvarChegada}>
              Salvar chegada
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!detalhe} onOpenChange={(o) => !o && setDetalhe(null)}>
        <DialogContent className="max-h-[min(90dvh,40rem)] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{detalhe?.titulo}</DialogTitle>
          </DialogHeader>
          {detalhe ? <Detalhe linhas={detalhe.linhas} onOpen={onOpen} /> : null}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <dt className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</dt>
      <dd className="truncate font-medium">{value}</dd>
    </div>
  );
}

function ChegadaBtn({ s, onChegada }: { s: Saida; onChegada: (s: Saida) => void }) {
  const tem = Boolean(s.hora_chegada);
  return (
    <button
      type="button"
      className={cn("text-left tabular-nums underline-offset-2 hover:underline sm:whitespace-nowrap", tem ? "font-medium" : "text-xs text-muted-foreground")}
      title={tem ? "Alterar só o horário de chegada" : "Registrar horário de chegada"}
      onClick={(e) => {
        e.stopPropagation();
        onChegada(s);
      }}
    >
      {tem ? formatTime(s.hora_chegada) : "Aguardando chegada"}
    </button>
  );
}

function Detalhe({ linhas, onOpen }: { linhas: SaidaLinha[]; onOpen: (s: Saida) => void }) {
  const total = linhas.reduce((a, r) => a + r.total, 0);
  const unidade = linhas[0]?.unidade || "";
  const pallets = linhas.every((r) => r.pallets != null) ? linhas.reduce((a, r) => a + (r.pallets || 0), 0) : null;
  const por = linhas.every((r) => r.porPallet != null) && new Set(linhas.map((r) => r.porPallet)).size === 1 ? linhas[0]?.porPallet : null;
  return (
    <div className="space-y-2">
      {pallets != null && por != null ? (
        <p className="text-sm text-muted-foreground">
          {formatNumber(pallets)} pallets × {formatNumber(por)} = {formatNumber(pallets * por)} {unidade}
        </p>
      ) : null}
      <ul className="divide-y divide-border rounded-xl border border-border">
        {linhas.map((r) => (
          <li key={r.id}>
            <button type="button" className="flex w-full items-center justify-between gap-3 px-3 py-2 text-left text-sm hover:bg-muted" onClick={() => onOpen(r.raw)}>
              <span>
                {formatDateBR(r.data)} · {r.pavilhao}
                {r.pallets != null ? ` · ${formatNumber(r.pallets)} pallets` : ""}
              </span>
              <span className="shrink-0 font-semibold tabular-nums">
                {formatNumber(r.total)} {r.unidade}
              </span>
            </button>
          </li>
        ))}
      </ul>
      <p className="text-sm font-semibold">
        Total: {formatNumber(total)} {unidade}
      </p>
    </div>
  );
}

function Campo({ label, children, className }: { label: string; children: ReactNode; className?: string }) {
  return (
    <label className={cn("block space-y-1", className)}>
      <Label className="text-xs text-muted-foreground">{label}</Label>
      {children}
    </label>
  );
}

function MercadoriaFiltro({
  items,
  valueId,
  onChange,
}: {
  items: Mercadoria[];
  valueId: string;
  onChange: (id: string, label: string) => void;
}) {
  const selected = items.find((m) => m.id === valueId);
  const [busca, setBusca] = useState(selected ? rotuloMercadoria(selected) : "");
  const [aberto, setAberto] = useState(false);
  const [destaque, setDestaque] = useState(0);
  const digitando = useRef(false);

  useEffect(() => {
    if (digitando.current) {
      digitando.current = false;
      return;
    }
    if (!valueId) {
      setBusca("");
      return;
    }
    const sel = items.find((m) => m.id === valueId);
    if (sel) setBusca(rotuloMercadoria(sel));
  }, [valueId, items]);

  const filtradas = useMemo(() => {
    const termo = selected && fold(busca) === fold(rotuloMercadoria(selected)) ? "" : busca;
    return items.filter((m) => mercadoriaCombina(m, termo)).slice(0, 24);
  }, [items, busca, selected]);

  function escolher(m: Mercadoria) {
    setBusca(rotuloMercadoria(m));
    setAberto(false);
    onChange(m.id, rotuloMercadoria(m));
  }

  function limparEscolha() {
    setBusca("");
    setAberto(true);
    setDestaque(0);
    onChange("", "");
  }

  return (
    <div className="relative">
      <Input
        value={busca}
        placeholder="Código ou nome"
        autoComplete="off"
        role="combobox"
        aria-expanded={aberto}
        aria-controls="saidas-mercadorias"
        className={valueId ? "pr-8" : undefined}
        onChange={(e) => {
          const next = e.target.value;
          setBusca(next);
          setAberto(true);
          setDestaque(0);
          if (valueId) {
            digitando.current = true;
            onChange("", "");
          }
        }}
        onFocus={() => setAberto(true)}
        onBlur={() => window.setTimeout(() => setAberto(false), 140)}
        onKeyDown={(e) => {
          if (e.key === "Escape") {
            setAberto(false);
            return;
          }
          if (!aberto || filtradas.length === 0) return;
          if (e.key === "ArrowDown") {
            e.preventDefault();
            setDestaque((n) => Math.min(n + 1, filtradas.length - 1));
          } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setDestaque((n) => Math.max(n - 1, 0));
          } else if (e.key === "Enter" && aberto) {
            e.preventDefault();
            escolher(filtradas[destaque] ?? filtradas[0]);
          }
        }}
      />
      {valueId ? (
        <button
          type="button"
          className="absolute right-2 top-1/2 grid h-6 w-6 -translate-y-1/2 place-items-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
          aria-label="Limpar mercadoria"
          onMouseDown={(e) => e.preventDefault()}
          onClick={limparEscolha}
        >
          <X className="h-3.5 w-3.5" />
        </button>
      ) : null}
      {aberto ? (
        <ul id="saidas-mercadorias" role="listbox" className="absolute z-30 mt-1 max-h-64 w-full overflow-y-auto rounded-xl border border-border bg-card p-1 shadow-card">
          {filtradas.length === 0 ? (
            <li className="px-3 py-4 text-center text-sm text-muted-foreground">Nenhuma mercadoria cadastrada com esse código ou nome.</li>
          ) : (
            filtradas.map((m, i) => (
              <li key={m.id} role="option" aria-selected={m.id === valueId}>
                <button
                  type="button"
                  className={cn(
                    "flex w-full items-baseline gap-2 rounded-lg px-3 py-2 text-left text-sm",
                    i === destaque || m.id === valueId ? "bg-mint text-foreground" : "hover:bg-muted",
                  )}
                  onMouseDown={(e) => e.preventDefault()}
                  onMouseEnter={() => setDestaque(i)}
                  onClick={() => escolher(m)}
                >
                  <span className="shrink-0 font-mono text-xs tabular-nums text-muted-foreground">{m.codigo}</span>
                  <ProductIcon nome={m.nome} codigo={m.codigo} foto={m.foto || m.foto_original} size="xs" />
                  <span className="min-w-0 truncate font-medium">{m.nome}</span>
                </button>
              </li>
            ))
          )}
        </ul>
      ) : null}
    </div>
  );
}

function CardKpi({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card px-3 py-2.5 shadow-card">
      <p className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-0.5 truncate text-lg font-semibold tabular-nums">{value}</p>
      {hint ? <p className="text-[10px] leading-tight text-muted-foreground">{hint}</p> : null}
    </div>
  );
}
