import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Bookmark, FileText, Search } from "lucide-react";
import { db } from "@/lib/store";
import { useDb } from "@/lib/use-db";
import { useSession } from "@/lib/session";
import { destinoDaSaida, isPavTransfer, lugarDaSaida } from "@/lib/catalog";
import { statusLabel, statusOf, tipoMovimentacaoOf } from "@/lib/movement";
import { MovementDetail } from "@/components/inventory/movement-detail";
import { formatDateBR, formatNumber, todayISO } from "@/lib/format";
import { notify } from "@/lib/notify";
import { exportDiaCompletoPdf } from "@/lib/reports";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/page-header";
import { PageStage } from "@/components/motion/page-stage";
import { CountUp } from "@/components/motion/count-up";
import { Badge } from "@/components/ui/badge";
import { ProductIcon } from "@/components/inventory/product-icon";
import { HojeCharts } from "@/components/hoje/hoje-charts";
import { fold } from "@/lib/utils";

export const Route = createFileRoute("/hoje")({ component: Hoje });

function Hoje() {
  const live = useDb();
  const { perfil } = useSession();
  const hoje = todayISO();
  const pavilhoes = live.listPavilhoes();
  const movs = live.listSaidas({ from: hoje, to: hoje });
  const entradas = movs.filter((s) => (s.tipo ?? "saida") === "entrada");
  const saidas = movs.filter((s) => (s.tipo ?? "saida") === "saida");

  const [qMov, setQMov] = useState("");
  const [view, setView] = useState<(typeof movs)[number] | null>(null);
  const transito = saidas.filter((s) => statusOf(s) === "em_transito").length;
  const produtosMov = new Set(movs.map((s) => s.mercadoria_id)).size;
  const contagensHoje = live.listContagens().filter((c) => c.data === hoje).length;
  const shownMovs = useMemo(() => {
    const term = fold(qMov.trim());
    if (!term) return movs;
    return movs.filter((s) => fold(`${s.mercadoria?.nome ?? ""} ${s.mercadoria?.codigo ?? ""}`).includes(term));
  }, [movs, qMov]);

  function pinFromMov(s: (typeof movs)[number]) {
    try {
      const tipo = s.tipo ?? "saida";
      if (tipo === "entrada") {
        const row = db.createAtalho({
          kind: "entrada",
          origem_pavilhao_id: s.pavilhao_id,
          mercadoria_id: s.mercadoria_id,
        });
        notify.success(`Atalho “${row.nome}” na lista.`);
        return;
      }
      const row = db.createAtalho({
        kind: isPavTransfer(s) ? "transferencia" : "saida",
        origem_pavilhao_id: s.pavilhao_id,
        destino_pavilhao_id: s.destino_pavilhao_id,
        destino_id: s.destino_id || undefined,
        mercadoria_id: s.mercadoria_id,
      });
      notify.success(`Atalho “${row.nome}” na lista.`);
    } catch (err) {
      notify.error(err instanceof Error ? err.message : "Não foi possível criar o atalho.");
    }
  }

  const weekday = new Date().toLocaleDateString("pt-BR", { weekday: "long" });

  return (
    <PageStage className="space-y-4">
      <PageHeader
        icon="today"
        title="Hoje"
        description={`${weekday} · ${formatDateBR(hoje)}. O que já saiu ou entrou hoje.`}
      >
        <Button variant="outline" onClick={() => exportDiaCompletoPdf(hoje)}>
          <FileText /> PDF do dia
        </Button>
      </PageHeader>

      <section className="grid grid-cols-2 gap-2 lg:grid-cols-5">
        <Kpi label="Entradas hoje" value={entradas.length} />
        <Kpi label="Saídas hoje" value={saidas.length} />
        <Kpi label="Em trânsito" value={transito} />
        <Kpi label="Produtos movimentados" value={produtosMov} />
        <Kpi label="Contagens" value={contagensHoje} />
      </section>

      <HojeCharts />

      <section className="space-y-2">
        <div className="flex flex-wrap items-end justify-between gap-2">
          <div>
            <h2 className="text-sm font-semibold">Movimentações de hoje</h2>
            <p className="text-xs text-muted-foreground">
              {qMov.trim()
                ? `${shownMovs.length} de ${movs.length}`
                : `${movs.length} ${movs.length === 1 ? "lançamento" : "lançamentos"}`}
              {" · mais recente primeiro"}
            </p>
          </div>
          <div className="relative w-full sm:w-64">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={qMov}
              onChange={(e) => setQMov(e.target.value)}
              placeholder="Buscar produto movimentado"
              className="h-9 pl-8"
              aria-label="Buscar produto nas movimentações de hoje"
            />
          </div>
        </div>
        {movs.length === 0 ? (
          <p className="rounded-xl border border-dashed border-border px-4 py-6 text-center text-sm text-muted-foreground">
            Ainda não lançaram nada hoje. {perfil?.nome ? `${perfil.nome.split(" ")[0]}, ` : ""}comece por uma{" "}
            <Link to="/entradas" className="font-medium text-foreground underline-offset-2 hover:underline">
              entrada
            </Link>
            .
          </p>
        ) : shownMovs.length === 0 ? (
          <p className="rounded-xl border border-dashed border-border px-4 py-6 text-center text-sm text-muted-foreground">
            Nenhum produto com “{qMov.trim()}” nas movimentações de hoje.
          </p>
        ) : (
          <ul className="grid max-h-[32rem] grid-cols-1 gap-2 overflow-y-auto pr-1 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
            {shownMovs.map((s) => {
              const tipo = tipoMovimentacaoOf(s);
              const accent = tipo === "entrada" ? "bg-primary" : tipo === "transferencia" ? "bg-foreground/25" : "bg-gold";
              return (
                <li key={s.id} className="min-w-0">
                  <article className="flex h-full overflow-hidden rounded-xl border border-border bg-card">
                    <div className={`w-1 shrink-0 ${accent}`} />
                    <button
                      type="button"
                      data-ctx={tipo === "entrada" ? "entrada" : "saida"}
                      data-id={s.id}
                      data-produto={s.mercadoria_id}
                      data-nome={s.mercadoria?.nome ?? ""}
                      data-codigo={s.mercadoria?.codigo ?? ""}
                      className="min-w-0 flex-1 px-2.5 py-2 text-left"
                      onClick={() => setView(s)}
                    >
                      <div className="flex items-start gap-2">
                        <ProductIcon nome={s.mercadoria?.nome ?? "Produto"} codigo={s.mercadoria?.codigo} size="sm" />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                            {s.hora_saida || s.created_at.slice(11, 16)} · {tipo === "entrada" ? "Entrada" : tipo === "transferencia" ? "Transferência" : "Saída"}
                            {s.mercadoria?.codigo ? ` · ${s.mercadoria.codigo}` : ""}
                          </p>
                          <p className="truncate text-sm font-medium leading-tight">{s.mercadoria?.nome ?? "Produto"}</p>
                          <p className="truncate text-[11px] text-muted-foreground">
                            {formatNumber(s.quantidade)} {s.unidade}
                            {" · "}
                            {tipo === "entrada" ? lugarDaSaida(pavilhoes, s) : `${lugarDaSaida(pavilhoes, s)} → ${destinoDaSaida(pavilhoes, s)}`}
                            {s.operador_nome ? ` · ${s.operador_nome}` : ""}
                          </p>
                        </div>
                      </div>
                      <div className="mt-1.5 flex flex-wrap gap-1">
                        {tipo === "entrada" ? <Badge variant="success">Entrada</Badge> : tipo === "transferencia" ? <Badge variant="muted">Transferência</Badge> : <Badge variant="gold">Saída</Badge>}
                        {s.desconta_estoque === false ? <Badge variant="gold">Somente registro</Badge> : null}
                        {tipo !== "entrada" ? <Badge variant="muted">{statusLabel(statusOf(s))}</Badge> : null}
                      </div>
                    </button>
                    <Button variant="ghost" size="icon" className="mt-1 mr-1 h-7 w-7 shrink-0" aria-label="Salvar atalho" onClick={() => pinFromMov(s)}>
                      <Bookmark className="h-3.5 w-3.5" />
                    </Button>
                  </article>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <MovementDetail view={view} onClose={() => setView(null)} />
    </PageStage>
  );
}

function Kpi({ label, value, hint }: { label: string; value: string | number; hint?: string }) {
  return (
    <Card>
      <CardContent className="px-3 py-2.5">
        <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</p>
        <p className="mt-0.5 text-base font-semibold tabular-nums leading-tight">
          {typeof value === "number" ? <CountUp value={value} /> : value}
        </p>
        {hint ? <p className="mt-0.5 text-[10px] text-muted-foreground">{hint}</p> : null}
      </CardContent>
    </Card>
  );
}
