import { useEffect, useRef, useState } from "react";
import { createRootRoute, HeadContent, Outlet, Scripts, useRouterState } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { SessionProvider, useSession } from "@/lib/session";
import { LoginScreen } from "@/components/login-screen";
import { AppShell } from "@/components/layout/app-shell";
import { Toaster } from "@/components/ui/sonner";
import { usePrefersReducedMotion } from "@/lib/motion";
import { useViewport } from "@/lib/use-viewport";
import appCss from "../styles.css?url";

const APP_NAME = "JG Garcia";

function Gate() {
  const { perfil } = useSession();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const phone = useViewport() === "phone";
  const lite = usePrefersReducedMotion();
  const [ready, setReady] = useState(false);
  const sawLogin = useRef(false);

  useEffect(() => {
    if (!perfil) sawLogin.current = true;
  }, [perfil]);

  useEffect(() => {
    if (perfil) return;
    if (pathname.startsWith("/qr-acesso") || pathname.startsWith("/operar") || pathname === "/") return;
    try {
      window.history.replaceState(null, "", "/");
    } catch {
      /* ignore */
    }
  }, [perfil, pathname]);

  useEffect(() => {
    setReady(true);
  }, [phone, lite]);

  if (pathname.startsWith("/qr-acesso") || pathname.startsWith("/operar")) return <Outlet />;
  if (perfil) return <AppShell />;
  return <LoginScreen mediaActive={ready && !phone && !lite} entering={false} />;
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: APP_NAME },
      { name: "theme-color", content: "#f6f4f4" },
      { name: "description", content: "Estoque, entradas, lotes e expedição da JG Garcia no CEASA RJ." },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
    ],
  }),
  component: () => (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        <HeadContent />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,400;0,14..32,500;0,14..32,600;0,14..32,700;1,14..32,400&display=swap"
        />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600;700&display=swap"
        />
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var root=document.documentElement;var ua=/Android|iPhone|iPod|iPad|Mobile|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);var m=localStorage.getItem('jg-viewport');if(ua&&m==='computer'){localStorage.removeItem('jg-viewport');m=null}var phone=false;if(m==='phone')phone=true;else if(m==='computer')phone=false;else phone=ua||window.innerWidth<768;root.classList.toggle('is-phone',phone);root.classList.toggle('is-computer',!phone);root.dataset.viewport=phone?'phone':'computer';if(localStorage.getItem('jg-theme-v2')==='dark'){root.classList.add('dark');root.style.colorScheme='dark'}else{root.classList.remove('dark');root.style.colorScheme='light'}}catch(e){}})()`,
          }}
        />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <SessionProvider>
            <Gate />
            <Toaster />
          </SessionProvider>
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  ),
});
