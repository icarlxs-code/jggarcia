import { todayISO } from "@/lib/format";
import { db } from "@/lib/store";

/** Texto curto do banco, sem foto e sem senha, para o assistente responder com o dado de agora. */
export function retratoOperacao(usuario: string): string {
  const hoje = todayISO();
  const ativos = db.listMercadorias(true);
  const comFoto = ativos.filter((m) => m.foto || m.foto_original).length;
  const criadosHoje = ativos.filter((m) => (m.created_at || "").slice(0, 10) === hoje);
  const doDia = db.listSaidas({ from: hoje, to: hoje });
  const entradas = doDia.filter((s) => (s.tipo ?? "saida") === "entrada");
  const saidas = doDia.filter((s) => (s.tipo ?? "saida") !== "entrada");
  const contagens = db.listContagens().filter((c) => (c.data || "").slice(0, 10) === hoje);
  const fretes = db.listFretes();
  const linhasMov = doDia.slice(0, 25).map((s) => {
    const tipo = (s.tipo ?? "saida") === "entrada" ? "entrada" : "saída";
    const nome = s.mercadoria?.nome ?? "produto";
    const lugar = s.pavilhao || s.origem || "";
    return `${tipo} · ${nome} · ${s.quantidade} ${s.unidade}${lugar ? ` · ${lugar}` : ""}`;
  });
  const estoque = [...ativos]
    .filter((m) => m.estoque > 0)
    .sort((a, b) => b.estoque - a.estoque)
    .slice(0, 20)
    .map((m) => `${m.codigo} ${m.nome}: ${m.estoque} ${m.unidade}`);
  const partes = [
    `Hoje: ${hoje}`,
    `Quem pergunta: ${usuario}`,
    `Produtos ativos: ${ativos.length}. Com foto: ${comFoto}. Cadastrados hoje: ${criadosHoje.length}.`,
    criadosHoje.length ? `Nomes de hoje: ${criadosHoje.map((m) => `${m.codigo} ${m.nome}`).join("; ")}` : "Nenhum produto novo hoje.",
    `Entradas de hoje: ${entradas.length}. Saídas de hoje: ${saidas.length}. Contagens de hoje: ${contagens.length}.`,
    `Fretes no sistema: ${fretes.length}.`,
    linhasMov.length ? `Movimentos de hoje:\n${linhasMov.join("\n")}` : "Nenhum movimento hoje.",
    estoque.length ? `Maiores estoques agora:\n${estoque.join("\n")}` : "Nenhum estoque positivo.",
  ];
  return partes.join("\n").slice(0, 12000);
}
