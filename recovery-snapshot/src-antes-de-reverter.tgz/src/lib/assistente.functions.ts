import { createServerFn } from "@tanstack/react-start";

type Fala = { papel: "user" | "assistant"; texto: string };

const janela: number[] = [];

function podeChamar() {
  const agora = Date.now();
  while (janela.length && agora - janela[0] > 60_000) janela.shift();
  if (janela.length >= 30) return false;
  janela.push(agora);
  return true;
}

export const perguntarAssistente = createServerFn({ method: "POST" })
  .validator((data: { pergunta: string; retrato: string; historico: Fala[] }) => data)
  .handler(async ({ data }) => {
    const pergunta = data.pergunta.trim().slice(0, 2000);
    if (!pergunta) return { ok: false as const, erro: "Escreva a pergunta." };
    if (!podeChamar()) return { ok: false as const, erro: "Muitas perguntas juntas. Espere um minuto." };

    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, erro: "O assistente não está disponível neste ambiente." };

    const historico = (data.historico ?? [])
      .slice(-6)
      .map((f) => ({ role: f.papel, content: String(f.texto ?? "").slice(0, 2000) }))
      .filter((f) => f.content.trim());

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 700,
        temperature: 0.3,
        messages: [
          {
            role: "system",
            content:
              "Você é o assistente da JG Garcia, dentro do controle de estoque. Responda em português, direto, como alguém da operação. Pode responder qualquer assunto. Quando a pergunta for sobre produto, estoque, entrada, saída, contagem, frete ou pavilhão, use somente o retrato abaixo. Se o número não estiver no retrato, diga que essa consulta não trouxe esse dado. Não invente quantidade, nome de produto nem saldo. Não mencione chave, servidor nem limite técnico.",
          },
          {
            role: "system",
            content: `Retrato da operação agora:\n${String(data.retrato ?? "").slice(0, 12000)}`,
          },
          ...historico,
          { role: "user", content: pergunta },
        ],
      }),
    });

    if (!res.ok) return { ok: false as const, erro: "Não consegui responder agora. Tente de novo." };
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const texto = body.choices?.[0]?.message?.content?.trim() ?? "";
    if (!texto) return { ok: false as const, erro: "A resposta veio vazia." };
    return { ok: true as const, texto };
  });
