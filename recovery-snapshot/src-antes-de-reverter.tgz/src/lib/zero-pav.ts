export const PAVILHOES_ZERAR = ["23", "44", "74"] as const;

export type PavilhaoZerar = (typeof PAVILHOES_ZERAR)[number];

/** Só estes códigos podem ser zerados. Qualquer outro valor é recusado. */
export function pavilhaoParaZerar(codigo: unknown): PavilhaoZerar | null {
  const raw = String(codigo ?? "").trim();
  if (raw === "23" || raw === "44" || raw === "74") return raw;
  return null;
}
